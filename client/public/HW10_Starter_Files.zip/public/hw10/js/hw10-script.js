// ============================================
// HW10 Monster Arena — Client-Side JavaScript
// COSC 2328 Web Development
// Professor McCurry
//
// YOUR NAME:
// YOUR SECTION:
//
// This file handles all DOM updates and fetch
// calls. The server only sends/receives JSON —
// this script is responsible for rendering HTML.
// ============================================


// ──────────────────────────────────────────────
// fetchMonsters()  (Part 4, Step 6)
// ──────────────────────────────────────────────
// This is a NAMED function — you will call it:
//   1. On page load (to populate the roster)
//   2. After a successful POST (recruit)
//   3. After a successful DELETE (retire)
//
// Steps:
//   - fetch GET /api/hw10/monsters
//   - Parse the JSON response
//   - Clear the roster container (innerHTML = '')
//   - Loop through the array and create a
//     .monster-card div for each monster
//   - Append each card to the roster
//   - Add a .catch() for network errors
// ──────────────────────────────────────────────

// TODO: Write fetchMonsters() and call it



// ──────────────────────────────────────────────
// Recruit Form Handler  (Part 5, Step 7)
// ──────────────────────────────────────────────
// Attach a 'submit' event listener to the
// recruit form. Inside the handler:
//
//   1. event.preventDefault()  ← CRITICAL
//   2. new FormData(event.target)
//   3. Object.fromEntries(formData)
//   4. JSON.stringify(data)
//   5. fetch POST /api/hw10/monsters with JSON
//   6. Display the server's message in #status
//   7. Call fetchMonsters() to refresh the roster
//   8. event.target.reset() to clear the form
//   9. .catch() for network errors
// ──────────────────────────────────────────────

// TODO: Add recruit form submit listener



// ──────────────────────────────────────────────
// Retire Button Handler  (Part 6, Step 8)
// ──────────────────────────────────────────────
// Attach a 'click' event listener to #retire-btn.
// Inside the handler:
//
//   1. Read the value from #retire-id
//   2. fetch DELETE /api/hw10/monsters/ + id
//   3. Check response.ok before re-fetching
//   4. Display success or error message in #status
//   5. Only call fetchMonsters() if response.ok
//   6. .catch() for network errors
// ──────────────────────────────────────────────

// TODO: Add retire button click listener



// ──────────────────────────────────────────────
// Battle Button Handler  (Part 7, Step 9)
// ──────────────────────────────────────────────
// Attach a 'click' event listener to #battle-btn.
// This does NOT need a new server route — it
// reuses GET /api/hw10/monsters and does all
// comparison logic here in the browser.
//
//   1. fetch GET /api/hw10/monsters
//   2. If fewer than 2 monsters, show message
//   3. Pick two DISTINCT random monsters
//   4. Calculate scores (attack + defense + hp)
//   5. Determine winner (or draw)
//   6. Display both fighters and winner in
//      #battle-results using innerHTML
//   7. .catch() for network errors
// ──────────────────────────────────────────────

// TODO: Add battle button click listener
